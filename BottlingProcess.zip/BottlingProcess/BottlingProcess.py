﻿"""
A Python-based simulation of an automated bottling station.

This script simulates both the PLC (Programmable Logic Controller) logic and
the physical hardware of a simple bottling line. It uses a state machine
to control the process of conveying, filling, and capping bottles. The status
is displayed in a text-based HMI in the terminal.
"""
import os
import threading
import time
from enum import Enum, auto


# Constants for the physical simulation
FILL_POSITION = 30       # Position of the filling station in cm
CAP_POSITION = 70        # Position of the capping station in cm
END_OF_CONVEYOR = 100    # End of the conveyor belt in cm
CONVEYOR_SPEED_CM_S = 20 # Conveyor speed in cm per second

# Constants for the PLC logic
FILL_TIME_S = 3.0        # Time to fill a bottle in seconds
CAP_TIME_S = 1.5         # Time to cap a bottle in seconds


class State(Enum):
    """Defines the operational states of the PLC's state machine."""
    IDLE = auto()
    WAITING_FOR_BOTTLE = auto()
    FILLING = auto()
    MOVE_TO_CAPPER = auto()
    CAPPING = auto()
    CYCLE_COMPLETE = auto()


class PhysicalSimulation:
    """Represents the physical hardware of the bottling station."""

    def __init__(self):
        """Initializes the state of all physical components."""
        self.bottle_position = 0.0
        self.conveyor_on = False
        self.fill_valve_open = False
        self.capper_active = False

    def update(self, delta_time):
        """
        Updates the physical state of the system over a time interval.

        Args:
            delta_time (float): The time elapsed since the last update.
        """
        if self.conveyor_on:
            self.bottle_position += CONVEYOR_SPEED_CM_S * delta_time
            # If bottle reaches the end, a new one appears at the start.
            if self.bottle_position >= END_OF_CONVEYOR:
                self.bottle_position = 0

    @property
    def bottle_at_fill_sensor(self):
        """Simulates a sensor at the filling station."""
        return FILL_POSITION - 1 < self.bottle_position < FILL_POSITION + 1

    @property
    def bottle_at_cap_sensor(self):
        """Simulates a sensor at the capping station."""
        return CAP_POSITION - 1 < self.bottle_position < CAP_POSITION + 1


class BottlingPLC:
    """
    Contains the control logic (state machine) for the bottling process.
    """

    def __init__(self):
        """Initializes the PLC state and internal variables."""
        self.state = State.IDLE
        self.system_enabled = False
        self.bottle_count = 0
        self.status_message = "System Idle. Type 'start' to begin."

        # Timers are managed by tracking start times
        self.timer_start_time = None

    def run_cycle(self, physical_sim, user_command):
        """
        Executes one scan cycle of the PLC logic.

        Args:
            physical_sim (PhysicalSimulation): The physical simulation object.
            user_command (str): A command from the user ('start', 'stop').
        """
        # --- Handle User Commands and System Enable ---
        if user_command == 'start' and self.state == State.IDLE:
            self.system_enabled = True
        elif user_command == 'stop':
            self.system_enabled = False
            self.status_message = "STOP command received. System Halted."

        # If system is disabled, reset to IDLE and turn off all outputs
        if not self.system_enabled:
            self.state = State.IDLE
            physical_sim.conveyor_on = False
            physical_sim.fill_valve_open = False
            physical_sim.capper_active = False
            return

        # --- Main State Machine ---
        if self.state == State.IDLE:
            self.status_message = "System Idle. Ready for next cycle."
            if self.system_enabled:
                self.state = State.WAITING_FOR_BOTTLE

        elif self.state == State.WAITING_FOR_BOTTLE:
            self.status_message = "Conveyor running, waiting for bottle..."
            physical_sim.conveyor_on = True
            if physical_sim.bottle_at_fill_sensor:
                physical_sim.conveyor_on = False
                self.state = State.FILLING
                self.timer_start_time = time.time()  # Start the fill timer

        elif self.state == State.FILLING:
            time_left = max(0, FILL_TIME_S - (time.time() - self.timer_start_time))
            self.status_message = f"Filling bottle... {time_left:.1f}s"
            physical_sim.fill_valve_open = True
            if time.time() - self.timer_start_time >= FILL_TIME_S:
                self.state = State.MOVE_TO_CAPPER

        elif self.state == State.MOVE_TO_CAPPER:
            self.status_message = "Moving bottle to capper..."
            physical_sim.fill_valve_open = False
            physical_sim.conveyor_on = True
            if physical_sim.bottle_at_cap_sensor:
                physical_sim.conveyor_on = False
                self.state = State.CAPPING
                self.timer_start_time = time.time()  # Start the cap timer

        elif self.state == State.CAPPING:
            time_left = max(0, CAP_TIME_S - (time.time() - self.timer_start_time))
            self.status_message = f"Capping bottle... {time_left:.1f}s"
            physical_sim.capper_active = True
            if time.time() - self.timer_start_time >= CAP_TIME_S:
                self.state = State.CYCLE_COMPLETE

        elif self.state == State.CYCLE_COMPLETE:
            physical_sim.capper_active = False
            self.bottle_count += 1
            # Immediately transition to restart the cycle
            self.state = State.WAITING_FOR_BOTTLE


def draw_hmi(plc, sim):
    """
    Clears the screen and draws a text-based HMI for the simulation.

    Args:
        plc (BottlingPLC): The PLC logic object.
        sim (PhysicalSimulation): The physical simulation object.
    """
    os.system('cls' if os.name == 'nt' else 'clear')

    print("╔════════════════════════════════════════════════════════════════════════════════╗")
    print("║                   PYTHON-BASED BOTTLING STATION CONTROL                      ║")
    print("╚════════════════════════════════════════════════════════════════════════════════╝")
    system_status = 'RUNNING' if plc.system_enabled else 'STOPPED'
    print(f" PLC State: {plc.state.name:<25} System Status: {system_status}")
    print(f" Status Msg: {plc.status_message:<65}")
    print(f" Bottle Count: {plc.bottle_count:<10}")
    print("─" * 78)

    # --- Process Mimic Display ---
    line = ['-'] * END_OF_CONVEYOR
    line[FILL_POSITION - 1:FILL_POSITION + 2] = ['|', 'F', '|']
    line[CAP_POSITION - 1:CAP_POSITION + 2] = ['|', 'C', '|']

    if 0 <= int(sim.bottle_position) < END_OF_CONVEYOR:
        line[int(sim.bottle_position)] = 'B'

    print("Conveyor: [S] " + "".join(line) + " [E]")

    fill_anim = "      " if not sim.fill_valve_open else "VVVVVV"
    cap_anim = "   " if not sim.capper_active else "███"

    print(f"{' ' * (FILL_POSITION + 12)}{fill_anim}")
    print(f"{' ' * (CAP_POSITION + 13)}{cap_anim}")
    print("─" * 78)
    conveyor_stat = 'ON' if sim.conveyor_on else 'OFF'
    fill_stat = 'OPEN' if sim.fill_valve_open else 'CLOSED'
    capper_stat = 'ACTIVE' if sim.capper_active else 'IDLE'
    print(f" Actuators | Conveyor: {conveyor_stat:<3} | Fill Valve: {fill_stat:<6} | Capper: {capper_stat:<6}")
    print("─" * 78)
    print("Commands: type 'start', 'stop', or 'exit' and press Enter.")


# This global variable is used for simple inter-thread communication.
# In a larger application, a queue.Queue would be more appropriate.
user_command = None

def get_user_input():
    """
    Runs in a separate thread to listen for user commands without
    blocking the main simulation loop.
    """
    global user_command
    while True:
        try:
            cmd = input().lower()
            if cmd in ['start', 'stop', 'exit']:
                user_command = cmd
            if cmd == 'exit':
                break
        except EOFError:
            # Handle case where input stream is closed
            break


def main():
    """The main entry point and simulation loop for the application."""
    global user_command
    plc = BottlingPLC()
    simulation = PhysicalSimulation()

    # Start the non-blocking input thread
    input_thread = threading.Thread(target=get_user_input, daemon=True)
    input_thread.start()

    last_time = time.time()
    try:
        while user_command != 'exit':
            # Calculate delta_time for physics-based movement
            current_time = time.time()
            delta_time = current_time - last_time
            last_time = current_time

            # Run one cycle of the PLC logic
            plc.run_cycle(simulation, user_command)
            user_command = None  # Consume the command after processing

            # Update the physical world based on PLC outputs
            simulation.update(delta_time)

            # Redraw the HMI
            draw_hmi(plc, simulation)

            # Control the simulation speed
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\nSimulation stopped by user (Ctrl+C).")
    finally:
        print("\nExiting.")


if __name__ == "__main__":
    main()